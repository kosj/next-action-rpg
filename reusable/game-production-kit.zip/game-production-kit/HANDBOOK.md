# 재사용 가능한 실패 사례와 제작 원칙

이 문서는 특정 게임의 설정을 복사하기 위한 문서가 아닙니다. **관찰 → 원인/한계 → 재사용할 원칙 → 목표 프로젝트에서 다시 확인할 값**을 연결합니다. 판본 **1.7.0**의 원본 항목 수·ID·상태·날짜·고정 커밋 근거는 [provenance.json](provenance.json)에 있습니다. 아래 ID는 그 출처를 찾는 키입니다.

주요 원관찰 환경은 Godot4.7.2·Blender4.3.2·Playwright1.62입니다. Blender 새 판본 실험이나 클라우드 브라우저의 상태는 해당 실험의 결과입니다. 새 프로젝트·다른 버전에서도 동일하다는 보장은 아니며, 과거 `verified`나 비용/치수를 목표 프로젝트의 현재 값으로 가져오지 않습니다.

## 프로젝트 기억과 실험

| 사례/출처 ID | 재사용할 원칙 | 목표 프로젝트에서 확인할 것 |
| --- | --- | --- |
| `toolchain-version-pin`, `blender-lts-batch-exit` | binary·템플릿 버전을 명시한다. 출력 파일 생성과 배치 정상 종료를 각각 검사한다. | 실제 실행 binary, export templates, 앱 버전, 프로세스 exit/timeout. 새 Blender가 출력했다고 바로 제작 기준을 바꾸지 않음 |
| `public-skills-provenance` | 공개 스킬의 원문·리비전·해시·LICENSE/NOTICE를 보존하고 프로젝트 판단을 분리한다. | 현재 공식 문서, 원문 변경, 적용할 부분과 적용하지 않을 부분 |
| `workspace-resume-checkpoints` | 비용이 큰 작업의 재개 정보를 지속되는 작업 위치에 기록한다. | 환경 교체 시 유지되는 경로, 완료 task ID·상태·원본 해시·실제 비용 |
| `headless-integration-lifecycle` | autoload/전체 씬이 필요한 테스트는 실제 노드 수명과 종료까지 다룬다. | runner 구조, 예약 coroutine, 노드/리소스 해제, stderr |
| `portable-production-knowledge-kit` | 프로젝트 사례·일반 절차·빈 템플릿을 분리하고 독립 경로의 ZIP 무결성과 source 일치를 검증한다. | 고정 출처·판본·파일별 manifest·복사한 스킬의 독립성. 원본 검증 상태를 대상에 승계하지 않음 |
| `headless-input-injection-boundary` | 입력 주입 시각과 게임의 실제 just-pressed 처리 경계를 함께 확인한다. | process/physics 신호 순서, 실제 행동 발생과 입력 해제 |

비용·권한·상태를 추측으로 채우지 않습니다. 외부 목록이 비거나 CLI가 실패하면 실제 도구 발견·읽기 호출·지원 API의 실패 범위를 확인합니다. 한 도구의 인증 오류가 다른 연결 경로까지 사용할 수 없다는 뜻은 아닙니다.

## 전투·복귀·저장·입력

| 사례/출처 ID | 재사용할 원칙 | 목표 프로젝트에서 확인할 것 |
| --- | --- | --- |
| `combat-swept-hit-query` | 베기 궤적의 연속 구간과 원형 범위 내부를 실제 물리 query로 검사한다. | 공격 거리/각도, sampling 간격, 안쪽 대상·대형 collider·한 공격의 중복 적중 |
| `parry-and-restore-state` | 성공·실패·복귀는 관련 타이머·버퍼·예약 효과를 함께 취소한다. | 경직·무적·콤보·쿨다운·지연 이벤트·새 생명/표현 epoch |
| `save-validated-backup` | 검증된 정상 primary만 backup으로 회전하고 실패 시 정상 상태를 보존한다. | 스키마/자료형/유한 값/범위, 쓰기·rename 실패와 롤백 |
| `save-settings-vs-journey` | 설정 저장과 실제 플레이 여정 시작은 서로 다른 상태다. | 타이틀 이어하기 조건, 새 게임/설정만 저장/복귀 시나리오 |
| `web-input-after-ui` | UI 클릭이 곧바로 공격으로 누수될 수 있다. 이벤트 소비와 fresh-press 경계를 둔다. | 마우스/패드/키보드별 재개 입력, 실제 공격 효과 |
| `touch-input-alias-lifecycle` | pointer 소유권과 장치별 action 해제 범위를 나누고 merged edge·GUI 전환을 검사한다. | cancel/release·초점/복귀·에뮬레이션 재진입, 동시 물리 입력·process/physics 경계. native fixture 통과와 실제 Web을 구분 |
| `mobile-driver-feedback-and-transient-observation` | 실제 입력 전에 짧은 상태의 읽기 전용 관찰을 시작하고, 같은 gesture의 geometry를 반복 조회하며 이전 입력을 오래 유지하지 않는다. | 입력 응답 지연·미래 frame snapshot·최종 실제 위치·pointer 종료·유한 시간. driver 실패와 앱 결함, 집중/전체 통과를 구분 |
| `charge-held-end-pose-regression` | 상태명이나 손가락 변화만으로 차지/장전 동작을 승인하지 않는다. | 끝 시점의 실제 몸/무기 이동, 임계 이후 hold, 취소와 release 타이밍 |

게임 코드의 초 단위를 클립 제작의 원본으로 씁니다. 클립이 부족하다고 피해 창을 임의로 늘리거나 검을 길게 만들어 접촉 문제를 숨기지 않습니다. 표현과 판정의 불일치는 실제 영상·marker·게임 데이터를 함께 보며 해결합니다.

## 웹 검증과 배포

| 사례/출처 ID | 재사용할 원칙 | 목표 프로젝트에서 확인할 것 |
| --- | --- | --- |
| `web-persistence-test`, `web-idbfs-async-commit` | 메모리/UI 상태와 durable commit을 분리하고 완전 종료·같은 프로필 재시작까지 검사한다. | 실제 저장 backend/primary key, 동기화 시점, 재시작 후 설정·진행 |
| `web-unsupported-shader-cache-userfs-directories` | 저장 대기 변경 전에 userfs 키와 cache 기능의 플랫폼별 실제 지원을 조사하고, 미지원 cache의 디렉터리 생성과 유효한 load/save를 구분한다. | 읽기 전용 metadata·고정 source, fresh/기존 프로필과 남는 디렉터리, shader compilation·품질·다른 플랫폼 보존. 키 변화와 primary 커밋·재시작·공개 QA는 별도 판정 |
| `browser-quality-before-combat` | 설정/저장 대기를 안전 구역에 배치하고 전투 검증을 별도로 유지한다. | 정상 입력으로 접근할 수 있는 구역, 검사 중 실제 HP/진행 보존 |
| `pages-public-deployment`, `pages-enablement-blocker` | repo 공개, 호스팅 최초 활성화, 배포, 공개 URL 실행은 별개 상태다. 해결된 과거 제약을 다시 현재 제약으로 쓰지 않는다. | 현재 Pages 설정과 token scope, 실제 실패 작업, 공개 빌드 식별자 |
| `release-assets-ci-token` | 릴리스 첨부는 해당 작업에 맞는 현재 인증 경로로 처리한다. | CLI·연결 앱·CI token 각각의 실제 권한과 만료 상태 |
| `public-browser-ca-trust` | 클라우드의 CA 신뢰 문제와 배포 장애를 구분하고 TLS 검증을 유지한다. | 정상 trust 환경/hosted runner의 실제 결과, URL·source commit |
| `web-loader-progress-after-dom-removal` | 로딩 UI 제거 뒤 도착하는 비동기 callback의 현재 element·작업 수명을 확인하고 cleanup/abort와 늦은 호출을 함께 다룬다. | 실제 DOM의 초기 표시·제거·late callback·cleanup, 기능 상태와 page error의 별도 판정. 집중 fixture 성공을 최종 브라우저 QA로 승계하지 않음 |
| `mobile-css-viewport-and-evidence` | CSS client·canvas backing·논리 viewport를 한 번씩 변환하고 native/Web safe area와 선택 API를 구분한다. | resize/회전·DPR·버튼 hit rect·UI 넘침·fullscreen 거부·브라우저 기능. 에뮬레이션과 실제 기기 증거를 분리 |
| `web-canvas-inline-css-viewport-feedback` | adaptive canvas의 inline CSS와 페이지 cascade가 viewport에 만드는 피드백을 확인하고 CSS 표시 영역과 bitmap/DPR 소유권을 분리한다. | 축소→확대·회전의 client/inline/computed/inner/outer/scroll·visualViewport scale·논리/bitmap 대조, 동일 산출물의 CSS-only A/B와 실제 PNG·터치 행동. 지표 clamp나 DPR 제거로 통과시키지 않음 |
| `touch-scroll-button-event-propagation` | 실제 버튼 위에서 시작한 scroll gesture를 보존하고 child consume·부모 전달·drag 시작 시 pending click 취소를 함께 검사한다. | wheel/touch 경로와 Slider 소유권 구분, 새 frame의 scroll value·콘텐츠 이동·pointer 해제·callback/우발 클릭, 실제 완료 버튼을 통한 설정 저장. 수정 후 브라우저 검증은 별도 |
| `godot-window-resize-reentrant-screen-attach` | 크기 변경 signal 안의 content-scale setter 재진입을 피한다. 입력은 즉시 종료하고 화면 설정은 외부 처리 후 deferred로 모은다. | CPU/public transform이 정상이어도 최종 screen attach가 오래될 수 있다. 동일 조건 원본 raster A/B와 대상 장면 이미지 guard를 사용 |

비동기 저장 관찰은 읽기 전용으로 수행합니다. 키 발견과 primary 읽기를 분리하고 관련 없는 payload를 전부 읽지 않습니다. async 결과는 실제로 await하고 그 값으로 제한된 반복을 합니다. 실패 시 단계별 저장/프레임 진단을 남기며 테스트가 저장을 쓰거나 강제 동기화하지 않습니다.

로컬 dirty export·PR용 합성 merge·main·태그는 서로 다른 source 식별자일 수 있습니다. 각각의 실제 빌드 번호를 기록하고 공개 주소가 기대한 commit을 실행하는지 확인합니다. 릴리스 파일은 실제 첨부를 다시 내려받아 bytes·SHA256·ZIP CRC·필수 실행 파일·의존 notices를 대조합니다.

[모바일 Web 절차](skills/godot-web-production/references/mobile-web-input.md)는 터치 소유권·해제·GUI 활성화와 화면 좌표를 함께 확인합니다. 재사용할 것은 경계와 검수 방법이며 특정 브라우저 지원표·감도·버튼 위치가 아닙니다. 이전의 native 회귀나 desktop touch fixture 통과를 실제 휴대기기의 실행·가독성·성능 승인으로 승계하지 않습니다. 현재 권한·계정·기기 접근 범위도 대상 프로젝트에서 확인합니다.

## 생성형 3D·Blender·애니메이션

| 사례/출처 ID | 재사용할 원칙 | 목표 프로젝트에서 확인할 것 |
| --- | --- | --- |
| `varco-official-mcp`, `varco-client-connection`, `varco-first-candidate` | 도구 존재·현재 연결·OAuth·실제 도구 호출을 구분한다. 완료 task를 입력으로 고정하고 명시 scope를 사용한다. | 현재 공식 MCP 스키마, 실제 Flow/노드/task, 완료 상태와 실행 범위 |
| `varco-generation-license` | 생성 당시 공개 범위·라이선스·원본·파생 권리와 실제 비용을 자산별로 기록한다. | 현재 정책, 입력 이미지/모션 권리, 상업 사용과 원본 재배포의 구분 |
| `varco-stock-duplicate-endpoints` | 원본의 중복 timestamp를 보존하고 별도 파생 재샘플을 검사한다. | 엄격한 구조 검사, motion fidelity, 전체 타이밍·loop |
| `varco-remesh-measured-budgets` | 삼각형 감소와 파일/텍스처 크기·리그·재질·프레임 비용은 별개다. | 실제 출력 수치, 이미지 재베이크, 메모리·실행 화면 |
| `skeletal-candidate-origin-normalization`, `armature-translation-roll-precision` | 공통 원점 이동을 먼저 증명하고 rest/topology/named weights를 보존한다. 변환 API의 roll/basis 오차를 검사한다. | 같은 리그인지, 허용오차, 전체 본/메시 관계와 표본 포즈. 실패를 허용오차 확대로 통과시키지 않음 |
| `importer-bone-display-helpers` | importer가 추가한 bone custom-shape helper와 실제 메시를 구분한다. | source 메시/삼각형, 실제 custom_shape 참조, skinned bounds. 이름/크기로 임의 제거하지 않음 |
| `generated-static-prop-axis-contract`, `skeletal-socket-scale-and-frame` | 실제 marker로 무기 축·길이를 대조하고 수입 리그 스케일만 보정한다. 수동 pose와 같은 프레임의 socket을 검사한다. | 리그 스케일/actor 외부 스케일, 최종 modifier 순서, grip·blade tip과 해부학적 접촉 |
| `character-capsule-visual-floor` | source 발바닥과 capsule bottom은 다른 좌표다. 필요한 시각 자식 offset만 계산한다. | 실제 collider 중심/높이·REST sole. 원래 프로젝트의 보정치를 복사하지 않음 |
| `skeletal-presentation-bridge`, `production-art-contract-checks` | 구조·클립/본 매핑·권한 경계와 실제 시간/화면 검증을 분리한다. | bind/정규화 weights/RESET/track 대상/필수 상태, 누락 시 명시 fallback |
| `project-authored-runtime-gaits` | stock 참고·프로젝트 저작·복제/리타겟의 provenance를 구분한다. 이동 속도와 보폭·stance를 함께 측정한다. | 저작 키·출처 권리, loop seam·reach·발 위치와 실제 이동/방향 |
| `production-phase-bounded-pose-blend`, `immutable-import-tracks-and-pose-feedback` | 수동 local pose 보간에는 다음 target이 모든 필요한 채널을 덮어써야 한다. phase/hold/취소와 판정 시간을 보존한다. | importer의 상수 트랙 제거, 전체 본 position/rotation/scale. 이 조건이 필요한 경로에만 적용 |
| `local-weight-solver-units-and-rejection` | solver의 단위/gradient와 기하학적 가능성을 구분하고 엄밀한 물리 상한을 반올림하지 않는다. | 고정 ROI·support, 독립 목적 미분, 정규화 후 실제 효과·새 압축/늘어짐·시각 판정 |
| `eye-socket-topology-and-whole-surface-fit` | 평면 삽입 대신 실제 눈꺼풀·소켓을 검토하고 주변 전체 표면과 rigid 안구/혼합 skin 경계를 함께 측정한다. | 원본 보존, 전체 주변 면·최대 cornea·동작 drift·좌표 독립 대조. 표본 교차0은 연속 증명이 아님 |
| `gltf-first-primitive-color-material-flag` | source 색상·imported array·실효 재질 flag를 각각 대조하고 자산 범위를 검증한 import 보정을 사용한다. | 현재 엔진에서 독립 재현·양자화 오차·공유 재질 불변·실제 반입/화면. 다른 판본에 버그를 가정하지 않음 |
| `blade-trail-world-markers-and-action-clock` | 실제 world marker 이력과 권한 있는 반열린 공격창을 읽고 표현 clock·중단 이력을 분리한다. | 외부 이동/scale·정지·취소·복귀·seek와 실제 on/off 가독성; VFX가 reach/피해를 소유하지 않음 |
| `weight-repair-per-edge-worsening` | 글로벌 최대/p99가 개선돼도 새 국소 악화를 찾는다. 전 프레임 표본과 실제 렌더로 채택 여부를 정한다. | 모든 key/중간 포즈의 edge별 변화, 부위 소유, 손/옷/갑옷 접촉과 같은 카메라 전후 |

원래 사례의 리깅·모션이 다른 자산에서도 맞는다고 가정하지 않습니다. source SHA·rest·named weight·모션 키를 대조하고 각 자산의 실제 골격과 의상 소유 영역을 확인합니다. 거부한 수선도 원인·근거·재현 절차를 보존하며 성공한 파생으로 표시하지 않습니다.

## 재질·환경·품질·성능

| 사례/출처 ID | 재사용할 원칙 | 목표 프로젝트에서 확인할 것 |
| --- | --- | --- |
| `courtyard-cc0-pbr-materials`, `godot-texture-import-budget-and-mips` | 색/데이터 채널·물리적 반복 크기·밉맵을 실제로 확인한다. 원본 JPEG와 runtime import/메모리는 다르다. | 공식 자산/작가/라이선스, sRGB albedo·linear normal/ARM, normal 방향·packed 채널·단위·실제 mips |
| `skin-material-semantics-rejection` | 피부 metallic의 실제 비정상 값을 확인해도 국소 hard material 경계가 새 seam을 만들면 기각한다. | 원본 UV/map·기본 factor·semantic mask와 불확실 경계, 동일 정면/측면의 일반 재질 비교. 구조 보존과 Game A/B·최종 채택은 별도 |
| `v013-generated-art-validation`, `v014-skeletal-preview` | 각 판본의 구조·실행 성공은 그 코드/자산의 범위에서 보존한다. | 실제 code/asset SHA·검사 범위·당시 화면, 현재 판본과의 차이 |
| `art-skeleton-contract`, `character-preview-final-art-review` | 과거 피벗/스킨 상태나 일부 pose 통과를 현재 최종 아트 승인으로 일반화하지 않는다. | 실제 runtime 종류, 전체 변형·전환·얼굴/손·머리/천·접촉 |
| `combat-quality-function-versus-heavy-impact` | [전투 기능과 타격감](skills/godot-web-production/references/combat-quality-review.md)을 나누고 dense key/기존 blend의 존재와 동작의 의미·접촉 표현을 별도로 검수한다. | 사용자/코드/정지 화면/정상1배속 영상·음향/기기 근거 구분, 참고 대상 동일성·관찰 범위, 약/강/차지의 명중·빗나감·방어·처치와 공통 접촉 피드백. 미관찰 영상의 타이밍·AAA 달성률을 만들지 않음 |
| `combat-reference-source-versus-provider-summary` | [참고 영상의 실제 미디어와 제공자 요약·preview](skills/godot-web-production/references/combat-quality-review.md)를 대조하고 원본 판본·편집 cut·직접 시각/청각·제공자 보고를 구분한다. | 공식 ID·실측 길이/해시·preview와 원본 해상도, 같은 shot의 접촉 전후, 기존 부유 대상·편집의 인과 한계, 오디오 존재와 직접 청취 구분. 공개 조사/계정 권한·기능 가격/승인 예산·정상 TLS 경로를 확인하고 비공개 식별자/서명 URL/raw 자산을 공개하지 않음. 현재 게임/새 프로젝트의 AV·기기·AAA 승인은 별도 |
| `charged-impact-confirmed-contact-clock` | 확정 접촉과 최종 표시 포즈의 시계·원본과 반입 곡선의 key/midpoint·양쪽 hitstop을 함께 비교한다. | 실제 actor frame/바닥 offset, IK pole과 관절 연속성, 씬 전체 재표본화·선택 보존·배포 바이트, 날 구간/반구 중심축·접촉 투영, query와 멈춘 검/잔상의 동일 시점, 충돌 복구를 포함한 실제 밀려남 예산, JS 안전 식별자와 실제 입력 관찰. 정상1배속 AV·실기기·AAA는 별도 |
| `motion-markers-versus-bone-derivatives` | [마커 정합과 본의 시간 변화](skills/godot-web-production/references/combat-quality-review.md)를 별도 검사하고 source/current·local/global·전체/본별 peak를 구분한다. | 조밀한 key와 일정 시간 표본의 손목 counter-rotation·관절/발 변화, 의도한 하체 변경과 기존 팔 경로 보존, 실제 원본 idle·half-open 복귀와 owner/ground 기준, 실제 충돌 root를 모르는 오프라인 발 보정의 한계. 고정-step movie의 논리1x 몸 동작과 interactive 전투/음향·기기 성능·AAA 승인은 별도 |
| `active-body-curve-and-loaded-contact` | [재저작 source·물리 곡선·무기 profile](skills/godot-web-production/references/combat-quality-review.md)을 묶어 검증하고 loaded pose의 이른 접촉을 실제 기하/receipt로 확인한다. | source/pin·좌표/길이/표본·큰 delta, 예측/실측 분리, 팔 peak와 누적 twist·새 국소 skin 악화, raw 보존/native triangle 대응·PBR atlas 공유, reference-only provider 후보. nominal projection/물리 AABB와 실제 raster의 몸/UI 가림·edge-on core를 별도 확인하고 기능 capture/정상 종료를 분리. 약한 core의 원인과 source-bound ray/실제 raster를 구분하고 명시적 art budget 수정·작은 프로토타입 채택 범위를 보존. 이전 source의 native/CI 통과를 새 카메라·최종 skin/시각·브라우저·기기·AAA로 승계하지 않음 |
| `quality-profiles-and-observed-lighting` | [품질의 실제 의미·고정 renderer 경로·같은 장면의 조명](skills/generated-3d-game-art/references/art-review.md#품질-모드와-조명-비교)을 연결한다. | UI/저장 index·runtime scale/DPR/shadow, source×mode paired raster, sky/ambient/reflection 혼합과 실제 dispatch, role-based 품질 권한, 기각한 shadow acne와 단일 변수 복구, support-ray 근사 grounding의 깊이·수명·캐시/질의 한도·중복 방지. source 고정 정지 화면의 제한된 채택과 자동 검사·실기기/모션/AAA를 구분 |
| `atmosphere-visual-skin-and-collision-authority` | [하늘·원경·바닥의 시각 완성도와 충돌 권한](skills/generated-3d-game-art/references/art-review.md#분위기원경시각-바닥과-충돌-권한)을 함께 기록한다. | 실제 horizon band/갑옷 전면·원경 실루엣·진입/연결 바닥, source×구도×품질 원본, 시각 node/표면/재질/그림자 budget과 camera 가림, floor skin 깊이·타일 m·실제 support ray. 이전 공개 검증·geometry 수·정지 화면을 새 구현이나 AAA/실기기 승인으로 승계하지 않음 |
| `generated-npc-budget-and-relic-role-authority` | [생성 NPC/guard의 공유 자산과 relic의 역할](skills/generated-3d-game-art/references/art-review.md#생성-npc공유-리그와-기능-오브젝트)을 실제 export 여유와 연결한다. | 최신 provider 도구·비용/권리·raw/rig/idle 파생, source/import/PCK/ZIP/GPU 차이와 이미 제외된 dependency, NPC/Enemy playback 독립성, 표시 pivot과 checkpoint/heal/save 권한·정상 입력. 생성/preview·구조 수치·재사용을 AAA/실기기 승인으로 승계하지 않음 |
| `continuous-arm-chain-observer-and-mixer-evidence` | 의도한 손 목표와 잘못된 중간 FK를 구분하고, 본의 연속성·국소 skin·관측 수명·실제 mixer 음향을 각각 검증한다. | 원래 키 보존과 새 목표 저작의 범위, local/world·key/mid 표본, 원본 곡선의 byte 보존, 실제 게임 AV와 직접 시청·청취의 차이 |
| `obstructed-camera-framing-and-latent-follow-state` | 주인공과 적이 함께 읽히는지 확인하고, 명시한 저투명도 임시 장벽의 카메라 정책을 actor 충돌과 분리한다. | 같은 World·실효 재질·모든 카메라 질의, 불투명 벽과 실제 capsule 차단, 이동 volume·latent follow 상태, body-only 기각과 실제 전후 구도·후반 위치 차이 |
| `decisive-heavy-action-and-baked-audio-timing` | 일반 강공격과 약공격의 차이를 실제 자세·칼날 곡선·이동·VFX/audio에서 확인하고 baked quiet lead를 먼저 읽는다. | 보존할 light channel, whole-file과 live payload, ordinary/charged LUT·물리 contact, 실제 Game AV와 offline gain, 실제 Web 예산. |
| `glb-live-reference-compaction-and-curve-path-portability` | live 참조의 payload·의미를 보존한 container remap과 runtime curve의 path metadata 적응을 분리한다. | stride/sparse/skin/image/모든 sampler, 독립 native 서명·negative byte 변형, source 절감과 실제 Web 차이, 미지원 schema 거부. |
| `skill-attack-profile-inheritance-and-full-journey-errors` | 공격 Resource 복제의 숨은 물리 곡선·flag·phase 계약과 caller의 시간 override를 함께 검증한다. | 실제 player의 모든 스킬 physics·전체 journey 오류 수집, fail-closed 유지, 스킬 없는 짧은 영상의 범위, 수정 전후 source 분리. |
| `resolved-stride-upper-attack-and-traveling-wave` | 실제 충돌 후 이동거리로 하체 보행을 진행하고 상체 공격 시간·진행체 판정을 연결한다. | 실제 Player 입력/벽 정지·상하체 본·공유 ledger·늦은 hitpause 소유권·1배속 화면을 각각 검사한다. 원본의 기능·유한 실제Game관측 verified 범위이며 새 프로젝트의 질감/AAA 승인이 아님 |
| `mixed-delivery-contact-oracles-and-same-strike-ledger` | 같은 공격을 공유하는 서로 다른 전달 수단의 계약을 분리하고 전체 타격 ledger를 먼저 검사한다. | 실제 혼합 receipt, 이전 기하/시간 guards 보존, 새 수단별 기하·피해·원점·사거리, predicate/최종집계/freeze/proof/source 동시 검토. 실패 원인과 순수 데이터 복구·새 live 승인 구분 |
| `public-vfx-curriculum-to-runtime-production-skill` | 공개 목차에서 확인한 범위와 독립 재저작 절차를 구분하고 목표 렌더러의 세부 기능을 대조한다. | 강의 미열람 범위, GPU emitter와 수동 방출/trail 제한의 차이, 베이크/atlas와 runtime, 실제 시각·성능/AAA는 각각 새 증거 필요. |
| `unreal-niagara-runtime-cache-and-integration-skill` | Unreal 전용 자산/이벤트·User Parameter·수명과 Sim Cache/atlas·scalability를 분리한 독립 스킬로 관리한다. | 실제 설치본 API/plugin 상태, 비활성 생성 후 초기화, Position/Vector·좌표, GPU의 CPU 비용, bounds/cull, 실제 cook/package·교전·기기 성능은 새 근거로 검사. |
| `redefinefx-causal-layering-and-controlled-vfx-experiments` | 공개 제작 설명을 자체 가설·고정 조건·변경 제어군·반증/기각 기준에 연결한다. | 국소 활성/비대상, 큰 형태/미세 디테일, 힘/충돌/표시, 재현 시드와 비교 매체를 구분한다. 자료 확인을 강의 실습·새 효과·AAA 승인으로 바꾸지 않음. |
| `aaa-representative-slice-acceptance`, `target-hardware-validation` | 대표 캐릭터·적·환경을 같은 판본으로 검수하고 최종 품질·실기기 성능은 별도 승인한다. | 전신/근접/플레이 영상, 조명/VFX 가독성, 목표 GPU·해상도·frame time·draw call·메모리 |
| `audio-server-deferred-playback-shutdown` | stop 요청과 mixer 최종 해제를 구분한다. 실제 참조 해제와 callback 재생 차단을 유한 조건으로 검사한다. | 대상 엔진의 audio 수명 모델, WeakRef/노드 해제, 반복 stop·명시 start |

환경 장식을 추가할 때는 공유 RNG의 호출 순서와 기존 충돌·카메라 경계를 보존합니다. 별도 시각용 RNG와 baseline 비교를 사용하고 collider 개수만 같다는 이유로 동일하다고 판단하지 않습니다. 동일 카메라의 실제 게임 화면으로 구도·표면·가독성을 검토합니다.

[국소 캐릭터 수정 절차](skills/generated-3d-game-art/references/local-character-polish.md)는 재질 수치·소유 mask·실제 경계의 시각 판정을 분리합니다. 보수적인 얼굴 내부 mask도 완전한 피부/머리 경계 분할을 뜻하지 않습니다. 중립 렌더의 seam gate에서 기각했다면 미실행 Game A/B나 실기기 검수를 통과로 적지 않습니다.

삼각형·본/클립 개수·텍스처 해상도·자동 검사 통과는 AAA 품질 인증서가 아닙니다. 얼굴·양손·갑옷·머리/천·전체 전환·공격 발디딤과 접촉, 재질·조명·VFX, 목표 기기 성능을 실제로 확인합니다. 소프트웨어 WebGL의 FPS를 목표 GPU 결과로 사용하지 않습니다.

## 새 프로젝트의 첫 적용 기록

1. 해당되는 스킬과 사례 ID를 선택합니다.
2. 원인 가설·현재 버전·적용할 조건·사용자 권한 범위를 기록합니다.
3. 가장 작은 실제 재현/확인 절차를 실행하고 원본과 결과 SHA를 남깁니다.
4. 결과를 `pending`/`verified`/`superseded`의 정확한 범위로 기록합니다.
5. 반복할 절차를 해당 프로젝트의 스킬에 반영합니다. 공통 원칙이 바뀌면 이 묶음의 판본·출처도 함께 갱신합니다.

이번 판본의 NPC 사례는 정적 인물의 근사 접지를 기존 actor budget과 분리하고, 수정 전 부유 원본·수정 후 모드별 원본과 새 native/export를 함께 보존합니다. 정지 pose의 개선을 animated foot shadow·연속 AV·하드웨어/AAA 승인으로 이전하지 않습니다.

실제 desktop Web의 quality 전환·live idle·저장·완전 재시작도 별도 근거로 남기고, 읽기 검증 전후 source/export byte 불변을 대조합니다. page 오류 배열과 HTTP client 종료 진단을 섞지 않으며 desktop 화면을 mobile의 다른 글꼴 크기/입력·clean 공개판 승인으로 이전하지 않습니다.

판본1.4.8은 원래 world key target과 오류가 있는 중간 FK의 보존을 구분합니다. 부모/자식 회전·국소 skin 악화·관측 terminal 수명·서로 다른 시계·실제 mixer PCM과 직접 청취의 경계도 다룹니다. 원본 69번째 사례의 verified는 제한된 source/native/실제45초 관측 범위입니다. 전체 시청/청취·skin·하드웨어/AAA는 pending이며 다른 프로젝트의 성공을 승인하지 않습니다. source 고정과 ZIP은 별도 절차입니다.

사례 70 camera 기록은 실제 gate/focus lag/short boom witness, endpoint와 이동 volume의 차이, latent follow base와 feedback 누적을 나눕니다. native 조건과 실패 원장을 보존하고 analytic 보존을 runtime bit 동일로 확대하지 않습니다. 실제 조립된 무기 profile은 파일명보다 source/geometry/marker SHA로 확인합니다.

원본 사례 69/70에서는 제한된 source/native/실제45초 구도 검증을 확인했습니다. browser/public·전체 시청/직접 청취/skin·목표 하드웨어/AAA는 pending입니다. body-only metric의 기각과 최종 actual pair의 late position variance를 보존하며, exact AV 배포를 지각 AV 승인으로 이전하지 않습니다. 고정 출처/ZIP은 source commit 후 별도로 관리합니다.

새 원본 사례71의 verified는 source/native와 실제 scripted Game의 제한된 관측·원본 검토 범위다. 사용자에게 약하게 읽힌 일반 강공격과 약공격을 같은 phase에서 비교하고, 새로운 몸 동작·실제 칼날 LUT·motor·VFX/audio를 함께 검증하는 절차를 준비한다. 기존 PCM의 baked quiet lead를 확인하기 전에 playback 지연을 더하지 않으며, offline gain 검사와 실제 Game/청취 승인을 구분한다. 새 후보의 native·export·실제 Game 원본에서 준비/검 궤적 개선을 확인했다. flat fan·국소 skin 위험·연속 시청/청취·실기기·AAA는 미승인이다.

새 사례72의 verified는 core GLB live-reference compaction의 별도 private 검증과 독립 guard 범위다. 참조 payload와 의미를 보존한 remap을 BIN prefix 동일과 구분하고, runtime curve의 path metadata를 numeric sample과 따로 검증한다. 독립 native core payload 보존은 확인했다. 실제 전체 Web은 증가했으므로 Web 최적화 성공으로 쓰지 않으며 시각/게임 승인은 pending이다.

판본1.4.9: source container·의미 보존·실제 native payload·최종 Web payload의 수치를 따로 유지한다. prefix를 보존할 수 없는 remap은 원본을 엄격히 고정한 독립 native 서명과 실제 byte 변형 negative로 검증한다. 작은 source가 전체 Web 절감을 뜻하지 않으며 payload 조사 없이 증가 원인을 추측하지 않는다. 출처는 실제 source commit의72항목으로 고정하며 ZIP/독립 재압축을 검증한다.

새 사례73의 verified는 실제 실패와 독립 스킬 생성·실제3cast native735/0 복구의 범위다. 수정 뒤 전체 모바일/공개 검증은 별도다. 공용 공격을 복제한 스킬이 새 물리 곡선·flag를 숨겨 상속하지 않는지 확인한다. 부분 native/charged 통과와 짧은 모션 영상이 전체 스킬·모바일 오류 검증을 대신하지 않는다. 이전 판본의 근거는 보존하며1.4.10은 실제73항목 source commit에 고정하고 ZIP을 독립 검증한다.

이동 공격과 진행체 사례74는 실제 이동과 애니메이션·판정의 연결을 검증하는 방법입니다. 요청 속도 대신 충돌 후 변위를 쓰고, 상하체 계층과 전신 공격 예외를 구분합니다. 검기의 표시 메시·swept query·거리 기준·벽의 최초 접촉과 근접 타격 ledger를 함께 검사합니다. 실제 입력으로 움직이는 Game의 1배속 영상과 피격 기록을 따로 검토하며, 기능 검사만으로 질감·AAA 승인을 하지 않습니다. 이 원본 사례는 기능·유한 실제Game관측 범위의 verified이며 연속 시청/청취·AAA와 새 프로젝트의 성공을 승인하지 않습니다.

사례75의 verified는 실제 실패와 혼합 receipt 순수 데이터 replay·음성 검사 복구 범위다. 새 투사체를 추가한 뒤 기존 공격명만으로 모든 접촉을 같은 물리 타격으로 검증하면 정상 기능을 기각할 수 있다. 반대로 새 접촉을 무시해 통과시키지 않는다. 코드·분류·시계·공유 ledger·source binding을 같이 확인하며 새 live/browser/공개와 대상 프로젝트의 승인은 별도로 남긴다.

[실시간 전투 VFX 스킬](skills/realtime-combat-vfx/SKILL.md)은 레이어/시간 설계부터 Blender 베이크·플립북·Godot 연결·실제 전투 검수까지 다룹니다. 공개 목차 기반의 참고 범위와 공식 문서의 기술 사실을 분리하며, 정확한 강의 recipe를 복원했다고 주장하지 않습니다.

[Unreal Niagara VFX 스킬](skills/unreal-niagara-vfx/SKILL.md)은 기존 Godot용을 덮어쓰지 않고 별도 폴더로 복사해 사용합니다. Sim Cache·플립북·live의 의미, Blueprint 초기화와 pool 수명, 실제 대상 빌드 검수를 해당 프로젝트 조건으로 채웁니다.
